//
//  User.swift
//  ConsumoAPI
//
//  Created by Leo A.Molina on 29/01/25.
//

import Foundation

struct User: Decodable, Identifiable {
    let userId: Int
    var id: Int
    let title: String
    let body: String
    
    var idString: String {
        return String(id)
    }
    
    var userIDString: String {
        return String(userId)
    }
}

//Llamar a la lsta de usuarios
func callAPIUsersList() -> [User]{
    var users: [User] = []
    guard let url = URL(string:"https://jsonplaceholder.typicode.com/posts") else{
        return users
    }
    
    let group = DispatchGroup()
    group.enter()
    
    let task = URLSession.shared.dataTask(with: url){
        data, response, error in

        if (data != nil){
            do{
                let exampleUser = try JSONDecoder().decode([User].self, from: data!)
                users = exampleUser
            }catch{
                print(error)
            }
        }
        group.leave()
    }
    task.resume()
    group.wait()
    return users
}

//Llamar a un usuario
func callAPIOneUser(userToCall: Int) -> User{
    var myUser: User = User(userId: 0, id: 0, title: "", body: "")
    guard let url = URL(string:"https://jsonplaceholder.typicode.com/posts/\(userToCall)") else{
        return myUser
    }
    
    let group = DispatchGroup()
    group.enter()
    
    let task = URLSession.shared.dataTask(with: url){
        data, response, error in

        if (data != nil){
            do{
                let exampleUser = try JSONDecoder().decode(User.self, from: data!)
                myUser = exampleUser
            }catch{
                print(error)
            }
        }
        group.leave()
    }
    task.resume()
    group.wait()
    print(myUser)
    return myUser
}
