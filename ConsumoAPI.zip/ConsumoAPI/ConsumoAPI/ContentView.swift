//
//  ContentView.swift
//  ConsumoAPI
//
//  Created by Leo A.Molina on 29/01/25.
//

import SwiftUI

var myUsers: [User] = callAPIUsersList()
var userOne = callAPIOneUser(userToCall: 1)

struct ContentView: View {
    
    var body: some View {
        VStack (alignment: .leading){
            VStack (alignment: .leading){
                HStack{
                    Text("Only user 1 data:")
                        .font(.largeTitle)
                }
                    Text("id: \(userOne.idString)")
                Text("userId: \(userOne.userIDString)")
                    Text("title: \(userOne.title)")
                    Text("body: \(userOne.body)")
            }
            .padding(.bottom)
            
            Text("Users table:")
                .font(.largeTitle)
            Table(myUsers){
                TableColumn("id", value: \.idString)
                TableColumn("userId", value: \.userIDString)
                TableColumn("title", value: \.title)
                TableColumn("body", value: \.body)
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
