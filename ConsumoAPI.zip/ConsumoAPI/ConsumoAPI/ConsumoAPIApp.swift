//
//  ConsumoAPIApp.swift
//  ConsumoAPI
//
//  Created by Leo A.Molina on 29/01/25.
//

import SwiftUI

@main
struct ConsumoAPIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
